---
aliases: []
tags:
  - seedling
  - Question
publish: true
---
>[! HOW TO CREATE A 🧠 QUESTION] 
>-> [[Study Questions]] are the first step in the scientific method of the Nerd Brain.
-> These Questions will allow us to create [[Engrams]] by using [[Neurons]] to structure the research data.
-> Use "[[]]" to create links to notes (they dont have to exist yet) and create an ID # using the unique title created
> -> Use Link Exploder from the Command Pallete to generate a base canvas
> -> Paste this prompt into Smart Connections chat:
> ```
> Based on my notes introduce me to the Nerd kNeuron & kEngrams and explain the rules, the procedures and the FAQ for their creation. suggest ideas based on the current study question
> ```
```
```

## Question ID

#202310160926_YOUR_QUESTION_NAME

>[!note] Question:
>How to implement Onchain Driving Permits?

# Research Links

[[permit_brain_dump]]
[[Driver licences in Canada  Wikipedia]]
